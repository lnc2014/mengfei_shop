// JavaScript Document

$(document).ready(function(){
	  $("#content .main .new ul li").hover(function(){
		   $(this).addClass("l_hover")
		  },function(){
			$(this).removeClass("l_hover")  
			  })
		
		$(function(){$("#slider").nivoSlider()})	  
		
			  
	   $(".remen ul li").hover(function(){ 
	       var liPath = $(this).attr("title")
		   $(this).find("img").attr("src",liPath)
		   },function(){
		   var imgTitle = $(this).find("img").attr("title")
           $(this).find("img").attr("src",imgTitle)
			   })
			   
			   
	   $("#content .main .c_nav ul.img_nav li h3").hover(function(){
		     $(this).addClass("h_hover")
		   },function(){
		     $(this).removeClass("h_hover")
		   })
		
	   $("#content .main .preferential ul li").hover(function(){
		   $(this).find("h4").css("color","#f0145c")
		   },function(){
			$(this).find("h4").css("color","#1c1c1c")  
		   })   
		return false;

})
function show()
{
/*html.style.overflow="hidden";*/
div1.style.display="block";//���ò�1��ʾ
/*body.style.overflow="hidden";*/
div2.style.display="block";//���ò�2����ʾ
}


//�ر���ʾ
function closeShow()
{
div1.style.display="none";
div2.style.display="none";
/*html.style.overflow="auto";
body.style.overflow="auto";*/
}
function name_onfocus()
{
   document.getElementById("mz").style.display="none";
}
function name_onblur()
{
   document.getElementById("mz").style.display="block";	
}
function pws_onfocus()
{
   document.getElementById("mm").style.display="none";
   
}
function pws_onblur()
{
   document.getElementById("mm").style.display="block";	
}
function over(k)
{ 
  document.getElementById(k).style.borderColor="#f0145c";	
}
function out(k)
{ 
  document.getElementById(k).style.borderColor="";	
}